import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Startscreen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Startscreen extends MyWorld
{

    /**
     * Constructor for objects of class Startscreen.
     * 
     */
    public Startscreen()
    {
    }
}
