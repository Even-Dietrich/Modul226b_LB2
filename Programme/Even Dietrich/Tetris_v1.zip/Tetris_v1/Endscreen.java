import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Endscreen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Endscreen extends MyWorld
{

    /**
     * Constructor for objects of class Endscreen.
     * 
     */
    public Endscreen()
    {
    }
}
