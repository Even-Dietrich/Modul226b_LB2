import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Spielwelt here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Spielwelt extends MyWorld
{

    /**
     * Constructor for objects of class Spielwelt.
     * 
     */
    public Spielwelt()
    {
    }
}
