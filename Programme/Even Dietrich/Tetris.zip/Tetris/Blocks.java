import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Blocks here.
 * 
 * @author ED
 * @version 3.0
 */
public class Blocks extends Actor
{
    private boolean onGround = false; // Is the block on the Ground
    private int pause = 100; //Time to gameover if its Touching the line
    private int warten = 400;
    /**
     * Act - do whatever the Blocks wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
       gameover();
    }    
    
    /**
     * Check if Pfeiltasten and Space are pressed, Turn and Move action or go down 
     */
    public void isKeyPressed()
    {
        int movedown= 320 - getY();//Move Down to Spielfeld
        if(onGround == false){
            if (Greenfoot.isKeyDown("up")) 
            {
                turn(90);
            }
            
            if (Greenfoot.isKeyDown("down")) 
            {
                turn(-90);
                
            }
            
            if (Greenfoot.isKeyDown("space")) 
            {
                setLocation(getX(), getY() + movedown); //move down to the ground
            }
            
            if (Greenfoot.isKeyDown("left")) 
            {
                setLocation(getX()-2, getY());
            }
            
            if (Greenfoot.isKeyDown("right")) 
            {
                setLocation(getX()+2, getY());
            }
    }
    }
    /**
     * Blocks move down, with diffrent speed depends on the level 
     */
    public void drop()
    {
        if(onGround == false)
        {
            Spielwelt Spielwelt = (Spielwelt)getWorld(); //Referenz zu Spielwelt
            //Level 1, Speed 2
            if(Spielwelt.level == 1){
             setLocation(getX(), getY()+ 1);
             nextBlock();
            }
            //Level 2, Speed 2
            else if (Spielwelt.level == 2){
             setLocation(getX(), getY()+ 2);
             nextBlock();
            }
            //Level 3, Speed 3
            else if(Spielwelt.level == 3){
              setLocation(getX(), getY()+ 3);
              nextBlock();
            }
        }
    }
    /**
     * Next Block if its at the Ground or ist touching another Block
     */
    public void nextBlock()
    {
        if(isTouching(spielfeld.class))
        {
            setLocation(getX(), getY());
            onGround = true;
            Spielwelt Spielwelt = (Spielwelt)getWorld(); //Referenz zu Spielwelt
            Spielwelt.addScore(20); // ADD 20 Points 
            Spielwelt.canNotSpawn(1);
        }
        if(isTouching(Blocks.class))
        {
            setLocation(getX(), getY());
            onGround = true;
            Spielwelt Spielwelt = (Spielwelt)getWorld(); //Referenz zu Spielwelt
            Spielwelt.addScore(20); // ADD 20 Points 
            Spielwelt.canNotSpawn(1);
        }
    }
    /**
     * If Block is Touching uper Line for 100 secounds its game over.
     */
    public void gameover(){
       if(isTouching(TopLine.class))
        {
        pause--;
        warten--;
         if(pause == 0)
            {
             setLocation(getX(), getY());
             Spielwelt Spielwelt = (Spielwelt)getWorld(); //Referenz zu Spielwelt
             Spielwelt.showEndScore();
             
             
        }
        if(warten == 0){
              Greenfoot.stop();
              Greenfoot.setWorld(new EndScreen());
             }
            
        } 
    }
}
