import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Blocks here.
 * 
 * @author ED
 * @version 3.0
 */
public class Blocks extends Actor
{
    private boolean onGround = false;
    /**
     * Act - do whatever the Blocks wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
       //gameover();
    }    
    
    /**
     * Check if Pfeiltasten ar pressed, Turn and Move action 
     */
    public void isKeyPressed()
    {
        int movedown= 320 - getY();//Move Down to Spielfeld
        if(onGround == false){
            if (Greenfoot.isKeyDown("up")) 
            {
                turn(90);
            }
            
            if (Greenfoot.isKeyDown("down")) 
            {
                setLocation(getX(), getY() + movedown); //move down to line
            }
            
            if (Greenfoot.isKeyDown("left")) 
            {
                setLocation(getX()-2, getY());
            }
            
            if (Greenfoot.isKeyDown("right")) 
            {
                setLocation(getX()+2, getY());
            }
    }
    }
    /**
     * Blocks move down
     */
    public void drop()
    {
        if(onGround == false)
        {
            setLocation(getX(), getY()+1);
            nextBlock();
        }
    }
    /**
     * Next Block if its at the Ground or ist touching another Block
     */
    public void nextBlock()
    {
        if(isTouching(spielfeld.class))
        {
            setLocation(getX(), getY());
            onGround = true;
            Spielwelt Spielwelt = (Spielwelt)getWorld();
            Spielwelt.addScore(20);
            
            Spielwelt.canNotSpawn(1);
        }
        if(isTouching(Blocks.class))
        {
            setLocation(getX(), getY());
            onGround = true;
            Spielwelt Spielwelt = (Spielwelt)getWorld();
            Spielwelt.addScore(20);
            
            Spielwelt.canNotSpawn(1);
        }
    }
    public void gameover(){
       if(isTouching(TopLine.class))
        {
            setLocation(getX(), getY());
            Greenfoot.stop();
            Greenfoot.setWorld(new EndScreen());
        } 
    }
}
