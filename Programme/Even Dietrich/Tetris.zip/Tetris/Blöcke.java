import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Blöcke here.
 * 
 * @author ED
 * @version 1.0
 */
public class Blöcke extends Actor

{
    public int delta = 1;
    public int speed = 1;
    public void act() 
    {
        checkKeyPress();
        fall();
        
    } 
    
    /**
     * Blöcke können bewegt und gedreht werden mit Pfeiltasten 
     */
    public void checkKeyPress()
    {
        //Pfeiltasten 
        if (Greenfoot.isKeyDown("up")) 
        {
            turn(-10);
        }
        
        if (Greenfoot.isKeyDown("down")) 
        {
            turn(10);
        }
        
        if (Greenfoot.isKeyDown("right")) 
        {
            setLocation(getX()+5, getY());
        }
        
        if (Greenfoot.isKeyDown("left")) 
        {
            setLocation(getX()-5, getY());
        }
    
    } 
    public void fall(){
    {
       setLocation(getX(), getY()+delta);
       
    }
    }
    
}
