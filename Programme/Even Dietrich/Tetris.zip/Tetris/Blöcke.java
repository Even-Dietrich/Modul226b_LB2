import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Blöcke here.
 * 
 * @author ED
 * @version 2.0
 */
public class Blöcke extends Actor

{
    private int checkLocation = 0; //Ausgangs Location 
    
    public void act() 
    {
        checkKeyPress();
        move();
        
    } 
    /**
     * Blöcke können bewegt und gedreht werden mit Pfeiltasten 
     */
    public void checkKeyPress()
    {
        //Pfeiltasten 
        if (Greenfoot.isKeyDown("up")) 
        {
            turn(-90);
        }
        
        if (Greenfoot.isKeyDown("down")) 
        {
            turn(90);
        }
        
        if (Greenfoot.isKeyDown("right")) 
        {
            setLocation(getX()+2, getY());
        }
        
        if (Greenfoot.isKeyDown("left")) 
        {
            setLocation(getX()-2, getY());
        }
    
    } 
     /**
     * Blöcke fallen herunter bis zu einem bestimmten Punkt 
     */
    public void move(){
    
       checkLocation = checkLocation + getY();//Location des Actors 
       if(checkLocation > 20)//Ende des Spielfeldes 
       {
           spielwelt spielwelt = (spielwelt)getWorld(); //MyWorld Referenz erstellen
           setLocation(getX(), getY());
       }else if(checkLocation < 20){ //Block bewegt sich überhalb der Linie 
            setLocation(getX(), getY()+1);
        
        
       }
       checkLocation = 0;
    }
}
    
