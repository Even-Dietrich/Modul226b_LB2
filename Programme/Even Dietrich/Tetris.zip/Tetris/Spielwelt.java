import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import greenfoot.Color;

/**
 * Write a description of class GameScreen here.
 * 
 * @author ED
 * @version 3.0
 */
public class Spielwelt extends World
{
    int spawnHeight = 0; //Spawn Height for Blocks Variable
    //int spawnPosition = 250;
    int groundHeight = 380; // Position of the ground Variable
    private int bloecke = 0; //Block Count Variable 
    private int time = 0; // Start Time Variable 
    int score; //Score Variable
    int level; // Level Variable 
    
    /**
     * Constructor for objects of class GameScreen.
     * 
     */
    public Spielwelt()
    {    
        super(500, 400, 1);
        getBackground().setColor(Color.BLACK);
        getBackground().fill();
        countTime();
        score = 0;
        level= 1;
        prepare();
        spawn();
        showScore();
        showTime();
        button();
        level();
        
    }
    /**
     * Act - do whatever the Blocks wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        spawn();
        countTime();
        level();
    }
    /**
     * Prepare the Playingfield, with ground and gameover line 
     */
    private void prepare()
    {
       Actor ground = new spielfeld();
       addObject(ground, 0, groundHeight);
       
       Actor topline = new TopLine();
       addObject(topline, 0, spawnHeight);
    }
    
    /**
     * Add Points to score
     */
    public void addScore(int points)
    {
        score = score + points;
        showScore();
        
    }
    
    /**
     * Zeigt den aktuellen Punktestand auf dem Bildschirm an.
     */
    public void showScore()
    {
        showText("Score: " + score, 100, 385); 
    }
    /**
     * Zeigt den aktuellen Punktestand auf dem Bildschirm an.
     */
    public void showEndScore()
    {
        showText("Score: " + score, 250, 100); 
    }
    /**
     * ADD Level, makes Blocks fall faster
     */
    private void level(){
        //Level 2 200-400 Point
        if(score > 200 && score < 400){
         level = 2;
         showText("Level:" + level, 200, 385);
        }
        //Level 3 400-Gameover Point
        else if(score > 400){
          level = 3; 
          showText("Level:" + level, 200, 385);
        }
        //Level 1 0-200 Point
        else if(score < 200){
          level = 1; 
          showText("Level:" + level, 200, 385);
        }
    }
  /**
     * Checks if there is any Blocks
  */
  public void canNotSpawn(int torf)
    {
        bloecke= bloecke - torf;
    }
    
  /**
     * Spwan Blocks at Random Positions
     */
  public void spawn()
    {
       if (bloecke == 0)    
       {
        int spawnPosition = Greenfoot.getRandomNumber(350) + 50; //Random Spawn
        int spawnHeight = 2; //Height were to spawn
        int random = Greenfoot.getRandomNumber(6); //Random Number 0-6
        if(random == 0)
       {
           Blocks I = new I();
           addObject(I, spawnPosition, spawnHeight);
       
        }else if(random == 1){
            Blocks J = new J();
            addObject(J, spawnPosition, spawnHeight);
        }
        else if(random == 2){
            Blocks L = new L();
            addObject(L, spawnPosition, spawnHeight);
        }
        else if(random == 3){
            Blocks O = new O();
            addObject(O, spawnPosition, spawnHeight);
        }
        else if(random == 4){
            Blocks S = new S();
            addObject(S, spawnPosition, spawnHeight);
        }
        else if(random == 5){
            Blocks T = new T();
            addObject(T, spawnPosition, spawnHeight);
        }
        else if(random == 6){
            Blocks Z = new Z();
            addObject(Z, spawnPosition, spawnHeight);
        }else
        {
           Blocks I = new I();
           addObject(I, spawnPosition, spawnHeight);
        }
         bloecke = 1;
        }
    }
    /**
     * ADD Buttons to Spielwelt
     */
    public void button(){
       Buttons pausebutton = new pausebutton(); //Pause Button, pause the Game
       addObject(pausebutton, 25, 385);
        
    }
    /**
     * Counts Playing Time 
     */
    private void countTime()
    {
        showTime();
        time++; //ADD 1 Secound to the Timer 
        
    }
     /**
     * Shows the Playing Time to the Player 
     */
    private void showTime()
    {
        showText("Time: " + time, 440, 385);
    }
    
}
