import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import greenfoot.Color;

/**
 * Write a description of class GameScreen here.
 * 
 * @author ED
 * @version 3.0
 */
public class Spielwelt extends World
{
    int spawnHeight = 0;
    //int spawnPosition = 250;
    int groundHeight = 380;
    private int bloecke = 0;
    int time;
    int score;
    
    /**
     * Constructor for objects of class GameScreen.
     * 
     */
    public Spielwelt()
    {    
        super(500, 400, 1);
        getBackground().setColor(Color.BLACK);
        getBackground().fill();
        
        score = 0;
        prepare();
        spawn();
        showScore();
        
        button();
    }
    
    public void act()
    {
        spawn();
        
    }
    /**
     * Prepare the Playingfield, with ground an gameover line 
     */
    private void prepare()
    {
       Actor ground = new spielfeld();
       addObject(ground, 0, groundHeight);
       
       Actor topline = new TopLine();
       addObject(topline, 0, spawnHeight);
    }
    
    /**
     * Fügt einige Punkte zu unserem aktuellen Punktestand hinzu. (Kann auch negativ sein.)
     * Wenn der Punktestand unter 0 fällt, ist das Spiel vorbei.
     */
    public void addScore(int points)
    {
        score = score + points;
        showScore();
        if (score == 1000) 
        {
            //Greenfoot.playSound("game-over.wav");
            Greenfoot.stop();
        }
    }
    
    /**
     * Zeigt den aktuellen Punktestand auf dem Bildschirm an.
     */
    private void showScore()
    {
        showText("Score: " + score, 100, 385); 
    }
    
    /**
     * Checks if there is any Blocks
     */
    public void canNotSpawn(int torf)
    {
        bloecke= bloecke - torf;
    }
    
    /**
     * Spwan Blocks, Random 
     */
    public void spawn()
    {
       if (bloecke == 0)    
       {
        int spawnPosition = Greenfoot.getRandomNumber(350) + 50;
        int spawnHeight = 2;
        if(Greenfoot.getRandomNumber(6) == 0)
       {
           Blocks I = new I();
           addObject(I, spawnPosition, spawnHeight);
       
        }else if(Greenfoot.getRandomNumber(6) == 1){
            Blocks J = new J();
            addObject(J, spawnPosition, spawnHeight);
        }
        else if(Greenfoot.getRandomNumber(6) == 1){
            Blocks L = new L();
            addObject(L, spawnPosition, spawnHeight);
        }
        else if(Greenfoot.getRandomNumber(6) == 1){
            Blocks O = new O();
            addObject(O, spawnPosition, spawnHeight);
        }
        else if(Greenfoot.getRandomNumber(6) == 1){
            Blocks S = new S();
            addObject(S, spawnPosition, spawnHeight);
        }
        else if(Greenfoot.getRandomNumber(6) == 1){
            Blocks T = new T();
            addObject(T, spawnPosition, spawnHeight);
        }
        else if(Greenfoot.getRandomNumber(6) == 1){
            Blocks Z = new Z();
            addObject(Z, spawnPosition, spawnHeight);
        }else
        {
           Blocks I = new I();
           addObject(I, spawnPosition, spawnHeight);
        }
        bloecke = 1;
        }
    }
    /**
     * ADD Buttons to Spielwelt
     */
    public void button(){
       Buttons pausebutton = new pausebutton();
       addObject(pausebutton, 25, 385);
        
    }
}
