import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class endscreen here.
 * 
 * @author ED 
 * @version 1.0
 */
public class endscreen extends World
{
    /**
     * Constructor for objects of class endscreen.
     * 
     */
    public endscreen()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        prepare();
       
  }
  /**
     * Shows Text Play again, Play again Button 
     * 
     */
  private void prepare()
    {
       showText("Play again?", 295, 100);
       Button Play_again = new playagain();
       addObject(Play_again, 295, 200);
    }
  
}