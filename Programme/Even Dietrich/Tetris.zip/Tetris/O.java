import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class O here.
 * 
 * @author ED
 * @version 1.0
 */
public class O extends Blöcke
{
    private int checkLocation = 0; //Ausgangs Location  
    /**
     * Act - do whatever the Blöcke wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        play();
        
        
    } 
      /**
     * Steuerung und bewegung der einzelnen Blöcke 
     */
    private void play(){
       checkLocation = checkLocation + getY();//Location des Actors   
       if(isTouching(S.class))//
       {
        setLocation(getX(), getY());
       }else if (checkLocation < 20){ //Block bewegt sich und fällt herunter oberhalb der linie 
            
        move();
        checkKeyPress();
       
       }
       checkLocation = 0;
    } 
}

