import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class PlayAgain here.
 * 
 * @author ED
 * @version 1.0
 */
public class PlayAgain extends Buttons
{
    /**
     * Act - do whatever the PlayAgain wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    /**
     * Act - do whatever the PlayButton wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        checkIfPressed();
    }   
    
    /**
     * Check if Button PlayAgain is pressed, creates Spielwelt if pressed. After the game is over
     * 
     */
    private void checkIfPressed()
    {
        if(Greenfoot.mouseClicked(this))
        {
            Greenfoot.setWorld(new Spielwelt());
        }
    }    
}
