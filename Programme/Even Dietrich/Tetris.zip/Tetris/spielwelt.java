import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class spielwelt here.
 * 
 * @author ED
 * @version 2.0
 */
public class spielwelt extends World
{

    /**
     * Constructor for objects of class spielwelt.
     * 
     */
    public spielwelt()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(10, 20, 30);  
        prepare();
        
    }
    /**
     * Prepare the Field 
     */
    public void prepare()
    {
      
       int x = Greenfoot.getRandomNumber(getWidth());
       int y = 0;
       int i = 0;
       while (i<1) {
       if(Greenfoot.getRandomNumber(7) <= 1){
           addObject( new S(), x, y );
        }
       if(Greenfoot.getRandomNumber(7) <= 2){
           addObject( new T(), x, y );
        }
       if(Greenfoot.getRandomNumber(7) <= 3){
           addObject( new J(), x, y );
        }
        if(Greenfoot.getRandomNumber(7) <= 4){
           addObject( new L(), x, y );
        }
        if(Greenfoot.getRandomNumber(7) <= 5){
           addObject( new Z(), x, y );
        }
        if(Greenfoot.getRandomNumber(7) <= 6){
           addObject( new O(), x, y );
        }
        if(Greenfoot.getRandomNumber(7) <= 7){
           addObject( new I(), x, y );
        }
    }}
     public void addplay()
    {
       startbutton play = new play();
       addObject(play, 100, 250);
       
       
       
       
    }
    
}
