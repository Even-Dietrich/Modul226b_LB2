import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
/**
 * Write a description of class spielwelt here.
 * 
 * @author ED
 * @version 2.0
 */
public class spielwelt extends World
{
    public int bloecke = 0; 
    /**
     * Constructor for objects of class spielwelt.
     * 
     */
    public spielwelt()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(10, 23, 30);  
        
        spawn();
    }
    /**
     * Prepare the Field 
     */
    public void spawn()
    {
   
       
        if(Greenfoot.getRandomNumber(7) == 0)
       {
         Blöcke I = new I();
         addObject(I, 250, 0);
       
        }else if(Greenfoot.getRandomNumber(7) == 1){
            Blöcke J = new J();
            addObject(J, 250, 0);
        }
          else if(Greenfoot.getRandomNumber(7) == 2){
            Blöcke L = new L();
            addObject(L, 250, 0);
        }
          else if(Greenfoot.getRandomNumber(7) == 3){
            Blöcke O = new O();
            addObject(O, 250, 0);
        }
          else if(Greenfoot.getRandomNumber(7) == 4){
            Blöcke S = new S();
            addObject(S, 250, 0);
        }
          else if(Greenfoot.getRandomNumber(7) == 5){
            Blöcke T = new T();
            addObject(T, 250, 0);
        }
          else if(Greenfoot.getRandomNumber(7) == 6){
            Blöcke Z = new Z();
            addObject(Z, 250, 0);
        }
    
    }
     /**
     * ADD Play Button
     */

     public void addplay()
    {
       startbutton play = new play();
       addObject(play, 100, 250);
       
       
       
       
    }
    
}
