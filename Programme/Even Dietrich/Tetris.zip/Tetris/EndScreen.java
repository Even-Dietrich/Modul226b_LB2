import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class EndScreen here.
 * 
 * @author ED
 * @version 1
 */
public class EndScreen extends World
{
  
    /**
     * Constructor for objects of class EndScreen.
     * 
     */
    public EndScreen()
    {    
        super(300, 400, 1);
        prepare();
        
    }
    
    /**
     * ADD Text, Score and Play Again Button 
     */
    public void prepare()
    {
        showText("Play again?", 150, 50);
        
        //showText("Congrats! You reached "+ Spielwelt.score, 200, 70);
        
        Buttons PlayAgain = new Play();
        addObject(PlayAgain, 150, 350);
    }
   
}
