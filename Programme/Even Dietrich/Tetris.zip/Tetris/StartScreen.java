import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class StartScreen here.
 * 
 * @author ED
 * @version 1.1
 */
public class StartScreen extends World
{

    /**
     * Constructor for objects of class StartScreen.
     * 
     */
    public StartScreen()
    {    
        super(300, 400, 1);
        prepare();

    }
    
    /**
     * Prepare Startscreen with Play Button 
     */
    public void prepare()
    {
       Buttons Play = new Play();
       addObject(Play, 150, 350);
    }
    
}
