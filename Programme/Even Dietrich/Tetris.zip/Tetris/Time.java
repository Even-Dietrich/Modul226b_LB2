import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class PlayTime here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Time extends Actor
{
    int time;
    /**
     * Act - do whatever the PlayTime wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
         time = 0;
         countTime();
    } 
     /**
     * Zählt die Spielzeit herunter und zeigt sie an. Stoppt das Spiel 
     * mit einer Gewinnbenachrichtigung, wenn die Zeit abgelaufen ist.
     */
    private void countTime()
    {
        time++;
        showTime();
        if (time == 0)
        {
            //showEndMessage();
            Greenfoot.stop();
        }
    }
    
    private void showTime()
    {
        //getWorld.showText("Time: " + time, 440, 385);
    }
}
