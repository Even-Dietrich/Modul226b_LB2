import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Startscreen here.
 * 
 * @author ED 
 * @version 1.0
 */
public class startscreen extends World
{

    /**
     * Constructor for objects of class Startscreen.
     * 
     */
    public startscreen()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(300, 400, 1);
        prepare();
       
    }
    /**
     * Shows Text Play again, Play again Button 
     * 
     */
    public void prepare()
    {
       Button startbutton = new startbutton();
       addObject(startbutton, 150, 350);
    }
  
}
