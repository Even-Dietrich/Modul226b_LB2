import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class pausebutton here.
 * 
 * @author ED
 * @version 1.0
 */
public class pausebutton extends Buttons
{
     /**
     * Set size of the image of the Pause Button
     */
    public pausebutton(){
        GreenfootImage image = getImage();
        image.scale(image.getWidth() - 190, image.getHeight() - 190);
        setImage(image);
    
    }
    
    /**
     * Act - do whatever the pausebutton wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */

    public void act() 
    {
        checkPressed();
        

    }   
      /**
     * If Button Pausebutton is pressed, Greenfoot gets paused
     * 
     */
    private void checkPressed()
    {
       if(Greenfoot.mouseClicked(this)){
           
           Greenfoot.stop(); //pause Game 
           
           
        }
    
    
    }    
}

