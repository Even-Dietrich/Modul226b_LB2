import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class pausebutton here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class pausebutton extends Button
{
/**
     * Act - do whatever the pausebutton wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public pausebutton()
    {
        
    }
     public void act() 
    {
        checkPressed();
    }   
      /**
     * Überprüft ob der Knopf gedurckt wurde, pausiert 
     * 
     */
    private void checkPressed()
    {
       if(Greenfoot.mouseClicked(this)){
           
           Greenfoot.stop();
           
           
        }
    
    
    }    
}

