import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class startbutton here.
 * 
 * @author ED 
 * @version 1.0
 */
public class startbutton extends Button
{
    /**
     * Act - do whatever the play wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
     
        checkPressed();
    }   
      /**
     * Überprüft ob der Knopf gedurckt wurde, Spiel  gestartet
     * 
     */
    private void checkPressed()
    {
       if(Greenfoot.mouseClicked(this)){
           
           Greenfoot.setWorld(new spielwelt());
        }
    }    
}
